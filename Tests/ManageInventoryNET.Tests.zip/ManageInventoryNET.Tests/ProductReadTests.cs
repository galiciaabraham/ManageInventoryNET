namespace ManageInventoryNET.Tests;

using Xunit;
using Bunit;
using Bunit.TestDoubles;
using System.Net;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text.Json;
using ManageInventoryNET.Data;
using ManageInventoryNET.Pages;
using ManageInventoryNET.Model;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.EntityFrameworkCore;
using System .ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;


public class DashboardPageTests : TestContext
{
    public DashboardPageTests()
    {
        var authContext = this.AddTestAuthorization();
        authContext.SetAuthorized("TestUser");
        authContext.SetRoles("Admin");

        var options = new DbContextOptionsBuilder<ProductContext>()
        .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
        .Options;

        var context = new ProductContext(options);

        Services.AddSingleton<ProductContext>(context);

        var category = new ManageInventoryNET.Model.Category { Id = 1, Name = "Brush" };
        
        var fakeProducts = new List<Product>
        {
            new Product { Id = 1, Name = "New Brush", Category = category, Quantity = "10", Price = "100" }
        };

        var fakePagedResult = new PagedResult<Product>
        {
            Items = fakeProducts,
            TotalCount = fakeProducts.Count
        };

        var json = JsonSerializer.Serialize(fakePagedResult);

        var handler = new FakeHttpMessageHandler(json, HttpStatusCode.OK);
        var httpClient = new HttpClient(handler)
        {
            BaseAddress = new Uri("http://localhost/")
        };

        Services.AddScoped(sp => httpClient);

    }
    [Fact]
    public void Header_DefaultState_ExpectedTitle()
    {
        var renderedComponent = RenderComponent<Dashboard>();
        var title = renderedComponent.Find("h1").TextContent;

        Assert.Equal("Dashboard", title);
    }

    [Fact]
    public void ProductName_DefaultState_ExpectedName()
    {
        var renderedComponent = RenderComponent<Dashboard>();

        renderedComponent.WaitForAssertion(() =>
        {
            var names = renderedComponent.FindAll("[data-label='Product Name']").Select(e => e.TextContent).ToList();
            Assert.Contains("New Brush", names);
        });
    }
}

public class FakeHttpMessageHandler : HttpMessageHandler
{
    private readonly string _json;
    private readonly HttpStatusCode _statusCode;
    public FakeHttpMessageHandler(string json, HttpStatusCode statusCode)
    {
        _json = json;
        _statusCode = statusCode;
    }

    protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
    {
        var response = new HttpResponseMessage(_statusCode)
        {
            Content = new StringContent(_json, System.Text.Encoding.UTF8, "application/json")
        };
        return Task.FromResult(response);
    }
}

public class PagedResult<T>
    {
        public List<T> Items { get; set; } = new();
        public int TotalCount { get; set; }
    }
