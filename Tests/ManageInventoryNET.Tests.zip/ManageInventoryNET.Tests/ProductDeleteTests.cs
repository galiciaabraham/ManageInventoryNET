namespace ManageInventoryNET.Tests;

using Xunit;
using Bunit;
using Bunit.TestDoubles;
using System.Net;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text.Json;
using ManageInventoryNET.Data;
using ManageInventoryNET.Pages;
using ManageInventoryNET.Model;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.EntityFrameworkCore;
using System .ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;


public class DeleteProductTests : TestContext
{

    private readonly ProductContext _context;
    // Removed unused Dashboard instance

    public DeleteProductTests()
    {
        var authContext = this.AddTestAuthorization();
        authContext.SetAuthorized("TestUser");
        authContext.SetRoles("Admin");

        var options = new DbContextOptionsBuilder<ProductContext>()
        .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
        .Options;

        _context = new ProductContext(options);

        var category = new Category { Id = 1, Name = "Brush" };


        _context.Products.Add(new Product { Id = 1, Name = "New Brush", Category = category, Quantity = "10", Price = "100" });
        _context.SaveChanges();

        Services.AddSingleton<ProductContext>(_context);

        var fakePagedResult = new PagedResult<Product>
        {
            Items = _context.Products.ToList(),
            TotalCount = 1
        };

        var json = JsonSerializer.Serialize(fakePagedResult);

        var handler = new FakeHttpMessageHandler(json, HttpStatusCode.OK);
        var httpClient = new HttpClient(handler)
        {
            BaseAddress = new Uri("http://localhost/")
        };

        Services.AddScoped(sp => httpClient);

        // Register a DeleteConfirmationDialog that triggers ConfirmDelete via the renderedComponent in the test method
        Services.AddTransient<DeleteConfirmationDialog>(_ => new FakeDeleteDialog(() =>
        {
            // We'll trigger ConfirmDelete via the renderedComponent in the test method
        }));

    }

    [Fact]
    public void Product_DefaultState_ExpectedDeletion()
    {
        var renderedComponent = RenderComponent<Dashboard>();

        // Simulate showing the delete confirmation for product with Id = 1
        renderedComponent.InvokeAsync(() => renderedComponent.Instance.ShowDeleteConfirmation(1));

        // Simulate confirming the delete (calls ConfirmDelete)
        renderedComponent.InvokeAsync(() => renderedComponent.Instance.ConfirmDelete());

        renderedComponent.WaitForAssertion(() =>
        {
            Assert.Equal(0, _context.Products.Count());
        });
    }
}

public class FakeDeleteDialog : DeleteConfirmationDialog
{
    private readonly Action _onConfirm;

    public FakeDeleteDialog(Action onConfirm)
    {
        _onConfirm = onConfirm;
    }

    public override Task ShowModal()
    {
        _onConfirm?.Invoke();
        return Task.CompletedTask;
    }
}