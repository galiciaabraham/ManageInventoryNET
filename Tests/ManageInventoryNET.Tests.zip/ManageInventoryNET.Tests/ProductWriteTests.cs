namespace ManageInventoryNET.Tests;

using Xunit;
using Bunit;
using Bunit.TestDoubles;
using System.Net;
using ManageInventoryNET.Data;
using ManageInventoryNET.Shared;
using ManageInventoryNET.Model;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.EntityFrameworkCore;


public class AddPageTests : TestContext
{
    private readonly ProductContext _context;
    public AddPageTests()
    {
        var authContext = this.AddTestAuthorization();
        authContext.SetAuthorized("TestUser");
        authContext.SetRoles("Admin");

        var options = new DbContextOptionsBuilder<ProductContext>()
        .UseInMemoryDatabase(databaseName: "dbTest")
        .Options;

        _context = new ProductContext(options);

        Services.AddSingleton<ProductContext>(_context);

    }

    [Fact]
    public void ProductSubmit_DefaultState_ExpectedResult()
    {
        var category = new ManageInventoryNET.Model.Category { Id = 1, Name = "Canvas" };
        var renderedComponent = RenderComponent<AddItem>();

        renderedComponent.Find("#newName").Change("Test Canvas");
        renderedComponent.Find("#newCategory").Change(category.Id);
        renderedComponent.Find("#newQuantity").Change("10");
        renderedComponent.Find("#newPrice").Change("199");

        renderedComponent.Find("form").Submit();

        renderedComponent.WaitForAssertion(() =>
        {
            Assert.Equal(1, _context.Products.Count());
            Assert.Equal("Test Canvas", _context.Products.First().Name);
        });
    }
}

